document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('quiz-form');
    const questionList = document.getElementById('question-list');
    const startQuizButton = document.getElementById('start-quiz');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const question = form.elements['question'].value;
        const option1 = form.elements['option1'].value;
        const option2 = form.elements['option2'].value;
        const option3 = form.elements['option3'].value;
        const option4 = form.elements['option4'].value;
        const correctOption = form.querySelector('input[name="correctOption"]:checked');
        const timer = form.elements['timer'].value;

        const listItem = document.createElement('li');
        listItem.textContent = question;
        if (timer) {
            listItem.textContent += ` (Timer: ${timer} seconds)`;
        }
        const optionsList = document.createElement('ul');
        const options = [option1, option2, option3, option4];
        options.forEach((option, index) => {
            const optionItem = document.createElement('li');
            optionItem.textContent = option;
            if (correctOption && correctOption.value === 'option' + (index + 1)) {
                optionItem.textContent += ' (Correct)';
            }
            optionsList.appendChild(optionItem);
        });
        listItem.appendChild(optionsList);
        questionList.appendChild(listItem);

        // Show Start Quiz button if at least one question is added
        startQuizButton.style.display = 'block';

        // Clear form fields
        form.reset();
    });

    startQuizButton.addEventListener('click', function () {
        // Redirect to the quiz page
        window.location.href = 'quiz.html';
    });
});
