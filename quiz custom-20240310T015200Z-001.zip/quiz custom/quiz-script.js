document.addEventListener('DOMContentLoaded', function () {
    const questionContainer = document.getElementById('question-container');
    const timerElement = document.getElementById('timer');

    const questions = []; // Add your questions here

    let currentQuestionIndex = 0;
    let timer;

    function displayQuestion() {
        const currentQuestion = questions[currentQuestionIndex];
        questionContainer.innerHTML = `<h2>${currentQuestion.question}</h2>`;
        currentQuestion.options.forEach((option, index) => {
            questionContainer.innerHTML += `<input type="radio" id="option${index + 1}" name="answer" value="${option}">
            <label for="option${index + 1}">${option}</label><br>`;
        });
    }

    function startTimer(duration) {
        let timeRemaining = duration;
        timer = setInterval(function () {
            timerElement.textContent = `Time remaining: ${timeRemaining} seconds`;
            if (timeRemaining <= 0) {
                clearInterval(timer);
                timerElement.textContent = 'Time\'s up!';
                setTimeout(moveToNextQuestion, 2000); // Move to the next question after 2 seconds
            }
            timeRemaining--;
        }, 1000);
    }

    function startExam() {
        displayQuestion();
        startTimer(10); // Change 10 to the desired duration in seconds for each question
    }

    function moveToNextQuestion() {
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            startExam(); // Move to the next question
        } else {
            // Exam ends, handle end of exam (e.g., display results)
            questionContainer.innerHTML = 'Exam completed!';
            timerElement.textContent = '';
        }
    }

    startExam(); // Start the exam when the page loads
});
